package com.capstore.repository;
/**
 * This is the repository for image upload 
 * @author yash naik
 */
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capstore.model.DBFile;
import com.capstore.model.Image;

import oracle.sql.BLOB;

@Repository
public interface DBFileRepository extends JpaRepository<DBFile, String> {

	public Image save(Image image);

	

}
