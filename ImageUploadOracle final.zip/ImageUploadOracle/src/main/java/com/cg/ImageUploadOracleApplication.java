package com.cg;
/**
 * @author yash naik
 * This is the spring boot application file
 * 
 */
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageUploadOracleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageUploadOracleApplication.class, args);
	}

}
