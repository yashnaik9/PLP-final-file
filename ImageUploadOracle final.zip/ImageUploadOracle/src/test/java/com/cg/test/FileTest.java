package com.cg.test;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capstore.service.DBFileStorageService;

public class FileTest {

	DBFileStorageService service = null;
	
	@Before
	public void setUp()   {
		service = new DBFileStorageService();
	}
	
	 @Test
	    public void testReadFileWithClassLoader2() {
	        ClassLoader classLoader = this.getClass().getClassLoader();
	        File file = new File(classLoader.getResource("C:\\Users\\yasnaik\\Desktop\\1.jifi").getFile());
	        assertTrue(file.exists()); 
	    }
		
	@After
	public void destroy()    {
		service = null;
	}
	
}
